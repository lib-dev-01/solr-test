// Pagination settings
let itemsPerPage = 2;
let currentPage = 1;
let totalPages = 1;
let filteredJournals = [];
let totalResults = 0;

// DOM Elements
const searchInput = document.getElementById('searchInput');
const searchButton = document.getElementById('searchButton');
const yearFilter = document.getElementById('yearFilter');
const categoryFilter = document.getElementById('categoryFilter');
const itemsPerPageSelect = document.getElementById('itemsPerPage');
const resultsContainer = document.getElementById('results');
const resultsCount = document.getElementById('resultsCount');
const loadingSpinner = document.querySelector('.loading-spinner');
const languageCheckboxes = document.querySelectorAll('input[name="language"]');

// Pagination elements
const prevPageButton = document.getElementById('prevPage');
const nextPageButton = document.getElementById('nextPage');
const pageInput = document.getElementById('pageInput');
const goToPageButton = document.getElementById('goToPage');
const pageNumbersContainer = document.querySelector('.page-numbers');

// Event Listeners
searchButton.addEventListener('click', performSearch);
searchInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        performSearch();
    }
});
yearFilter.addEventListener('change', performSearch);
categoryFilter.addEventListener('change', performSearch);

// Language checkbox change
languageCheckboxes.forEach(checkbox => {
    checkbox.addEventListener('change', performSearch);
});

// Items per page change
itemsPerPageSelect.addEventListener('change', () => {
    itemsPerPage = parseInt(itemsPerPageSelect.value);
    currentPage = 1;
    performSearch();
});

// Pagination event listeners
prevPageButton.addEventListener('click', () => {
    if (currentPage > 1) {
        currentPage--;
        performSearch();
    }
});

nextPageButton.addEventListener('click', () => {
    if (currentPage < totalPages) {
        currentPage++;
        performSearch();
    }
});

goToPageButton.addEventListener('click', () => {
    const page = parseInt(pageInput.value);
    if (page && page >= 1 && page <= totalPages) {
        currentPage = page;
        performSearch();
    }
});

pageInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        const page = parseInt(pageInput.value);
        if (page && page >= 1 && page <= totalPages) {
            currentPage = page;
            performSearch();
        }
    }
});

// Initial display
performSearch();

function showLoading() {
    loadingSpinner.classList.add('active');
    resultsContainer.style.opacity = '0.3';
    resultsContainer.style.pointerEvents = 'none';
}

function hideLoading() {
    loadingSpinner.classList.remove('active');
    resultsContainer.style.opacity = '1';
    resultsContainer.style.pointerEvents = 'auto';
}

async function performSearch() {
    showLoading();
    
    try {
        const searchTerm = searchInput.value;
        const selectedYear = yearFilter.value;
        const selectedCategory = categoryFilter.value;
        
        // Get selected languages
        const selectedLanguages = Array.from(languageCheckboxes)
            .filter(checkbox => checkbox.checked)
            .map(checkbox => checkbox.value);

        // Prepare search parameters
        const params = new URLSearchParams({
            search: searchTerm,
            year: selectedYear,
            category: selectedCategory,
            page: currentPage,
            itemsPerPage: itemsPerPage,
            languages: selectedLanguages.join(',')
        });

        // Make API call to search.php
        const response = await fetch(`search.php?${params.toString()}`);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const data = await response.json();
        
        if (data.error) {
            throw new Error(data.message || 'An error occurred while searching');
        }

        filteredJournals = data.journals;
        totalPages = data.totalPages;
        totalResults = data.totalResults;
        
        // Ensure currentPage is within valid range
        if (currentPage > totalPages && totalPages > 0) {
            currentPage = totalPages;
            // Perform search again with corrected page
            performSearch();
            return;
        }
        
        updateResultsCount();
        updatePagination();
        displayJournals();
    } catch (error) {
        console.error('Error fetching search results:', error);
        resultsContainer.innerHTML = `<p class="error">An error occurred while fetching results: ${error.message}</p>`;
    } finally {
        hideLoading();
    }
}

function updateResultsCount() {
    resultsCount.textContent = totalResults;
}

function displayJournals() {
    resultsContainer.innerHTML = '';

    if (filteredJournals.length === 0) {
        resultsContainer.innerHTML = '<p class="no-results">No journals found matching your criteria.</p>';
        return;
    }

    // const startIndex = (currentPage - 1) * itemsPerPage;
    // const endIndex = startIndex + itemsPerPage;
    // const journalsToDisplay = filteredJournals.slice(startIndex, endIndex);

    filteredJournals.forEach(journal => {
        const journalItem = document.createElement('div');
        journalItem.className = 'journal-item';
        
        journalItem.innerHTML = `
            <div class="journal-content">
                <div class="journal-image">
                    <img src="${journal.image}" alt="${journal.title}">
                </div>
                <div class="journal-details">
                    <h3 class="journal-title">${journal.title}</h3>
                    <div class="journal-meta">
                        <span class="year">Year: ${journal.year}</span>
                        <span> | </span>
                        <span class="category">Category: ${journal.category}</span>
                    </div>
                    <p class="journal-abstract">${journal.abstract}</p>
                </div>
            </div>
        `;

        resultsContainer.appendChild(journalItem);
    });
}

function updatePagination() {
    // Update previous/next buttons
    prevPageButton.disabled = currentPage === 1;
    nextPageButton.disabled = currentPage === totalPages;

    // Clear existing page numbers
    pageNumbersContainer.innerHTML = '';

    // Calculate range of pages to show
    let startPage = Math.max(1, currentPage - 2);
    let endPage = Math.min(totalPages, currentPage + 2);

    // Add page numbers
    for (let i = startPage; i <= endPage; i++) {
        const pageButton = document.createElement('button');
        pageButton.className = `page-button${i === currentPage ? ' active' : ''}`;
        pageButton.textContent = i;
        pageButton.addEventListener('click', () => {
            currentPage = i;
            performSearch();
        });
        pageNumbersContainer.appendChild(pageButton);
    }

    // Update page input
    pageInput.value = '';
    pageInput.placeholder = `Page ${currentPage} of ${totalPages}`;
} 