<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Journal Search</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="banner">
                <h1>Journal Search</h1>
                <p>Find and explore academic journals</p>
            </div>
            <div class="search-container">
                <input type="text" id="searchInput" placeholder="Search journals...">
                <button id="searchButton">Search</button>
            </div>
        </header>
        
        <main>
            <div class="content-wrapper">
                <aside class="sidebar">
                    <h2>Filters</h2>
                    <div class="filter-section">
                        <h3>Year</h3>
                        <select id="yearFilter">
                            <option value="">All Years</option>
                            <option value="2024">2024</option>
                            <option value="2023">2023</option>
                            <option value="2022">2022</option>
                        </select>
                    </div>
                    <div class="filter-section">
                        <h3>Category</h3>
                        <select id="categoryFilter">
                            <option value="">All Categories</option>
                            <option value="science">Science</option>
                            <option value="technology">Technology</option>
                            <option value="medicine">Medicine</option>
                        </select>
                    </div>
                </aside>
                
                <div class="search-results">
                    <div class="results-header">
                        <div class="total-results">
                            <span id="resultsCount">0</span> results found
                        </div>
                        <div class="pagination">
                            <button id="prevPage" class="pagination-button" disabled>Previous</button>
                            <div class="page-numbers">
                                <button class="page-button active">1</button>
                            </div>
                            <button id="nextPage" class="pagination-button">Next</button>
                            <div class="items-per-page">
                                <label for="itemsPerPage">Items per page:</label>
                                <select id="itemsPerPage">
                                    <option value="2">2</option>
                                    <option value="4">4</option>
                                    <option value="6">6</option>
                                    <option value="8">8</option>
                                </select>
                            </div>
                            <div class="page-jump">
                                <input type="number" id="pageInput" min="1" placeholder="Page">
                                <button id="goToPage">Go</button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="loading-spinner">
                        <div class="spinner"></div>
                        <p>Loading results...</p>
                    </div>

                    <div id="results" class="results-list">
                        <!-- Results will be populated here -->
                    </div>
                </div>
            </div>
        </main>
    </div>
    <script src="script.js"></script>
</body>
</html> 