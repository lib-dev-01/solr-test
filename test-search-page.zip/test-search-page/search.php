<?php
header('Content-Type: application/json');

// Static journal data
$staticJournals = [
    [
        "title" => "The Impact of Artificial Intelligence on Healthcare",
        "abstract" => "This paper explores how AI is transforming healthcare delivery, diagnosis, and treatment planning.",
        "year" => "2024",
        "category" => "Healthcare",
        "image" => "images/ai-healthcare.jpg",
        "language" => "English"
    ],
    [
        "title" => "人工智能在医疗保健中的影响",
        "abstract" => "本文探讨了人工智能如何改变医疗保健服务、诊断和治疗计划。",
        "year" => "2024",
        "category" => "Healthcare",
        "image" => "images/ai-healthcare.jpg",
        "language" => "Chinese"
    ],
    [
        "title" => "Sustainable Energy Solutions for Urban Development",
        "abstract" => "A comprehensive study of renewable energy integration in modern city planning and infrastructure.",
        "year" => "2023",
        "category" => "Environment",
        "image" => "images/sustainable-energy.jpg",
        "language" => "English"
    ],
    [
        "title" => "城市发展的可持续能源解决方案",
        "abstract" => "关于现代城市规划和基础设施中可再生能源整合的综合研究。",
        "year" => "2023",
        "category" => "Environment",
        "image" => "images/sustainable-energy.jpg",
        "language" => "Chinese"
    ],
    [
        "title" => "Machine Learning in Financial Markets",
        "abstract" => "Analysis of machine learning applications in stock market prediction and trading strategies.",
        "year" => "2024",
        "category" => "Finance",
        "image" => "images/ml-finance.jpg",
        "language" => "English"
    ],
    [
        "title" => "金融市场中的机器学习",
        "abstract" => "分析机器学习在股票市场预测和交易策略中的应用。",
        "year" => "2024",
        "category" => "Finance",
        "image" => "images/ml-finance.jpg",
        "language" => "Chinese"
    ],
    [
        "title" => "Climate Change and Biodiversity",
        "abstract" => "Research on the effects of climate change on global biodiversity and ecosystem stability.",
        "year" => "2023",
        "category" => "Environment",
        "image" => "images/climate-biodiversity.jpg",
        "language" => "English"
    ],
    [
        "title" => "气候变化与生物多样性",
        "abstract" => "关于气候变化对全球生物多样性和生态系统稳定性影响的研究。",
        "year" => "2023",
        "category" => "Environment",
        "image" => "images/climate-biodiversity.jpg",
        "language" => "Chinese"
    ],
    [
        "title" => "Blockchain Technology in Supply Chain",
        "abstract" => "Examining the role of blockchain in improving supply chain transparency and efficiency.",
        "year" => "2024",
        "category" => "Technology",
        "image" => "images/blockchain-supply.jpg",
        "language" => "English"
    ],
    [
        "title" => "供应链中的区块链技术",
        "abstract" => "研究区块链在提高供应链透明度和效率方面的作用。",
        "year" => "2024",
        "category" => "Technology",
        "image" => "images/blockchain-supply.jpg",
        "language" => "Chinese"
    ],
    [
        "title" => "Mental Health in the Digital Age",
        "abstract" => "Study of the impact of digital technology on mental health and well-being.",
        "year" => "2023",
        "category" => "Healthcare",
        "image" => "images/mental-health.jpg"
    ],
    [
        "title" => "Quantum Computing: Current State and Future Prospects",
        "abstract" => "Overview of quantum computing developments and potential applications.",
        "year" => "2024",
        "category" => "Technology",
        "image" => "images/quantum-computing.jpg"
    ],
    [
        "title" => "Sustainable Agriculture Practices",
        "abstract" => "Analysis of modern sustainable farming techniques and their environmental impact.",
        "year" => "2023",
        "category" => "Environment",
        "image" => "images/sustainable-agriculture.jpg"
    ],
    [
        "title" => "Cybersecurity in the Age of IoT",
        "abstract" => "Research on security challenges and solutions for Internet of Things devices.",
        "year" => "2024",
        "category" => "Technology",
        "image" => "images/iot-security.jpg"
    ],
    [
        "title" => "Urban Planning and Smart Cities",
        "abstract" => "Study of smart city technologies and their implementation in urban planning.",
        "year" => "2023",
        "category" => "Technology",
        "image" => "images/smart-cities.jpg"
    ]
];

// Get search parameters
$query = isset($_GET['search']) ? urlencode(trim($_GET['search'])) : '*:*';
$year = isset($_GET['year']) ? trim($_GET['year']) : '';
$category = isset($_GET['category']) ? trim($_GET['category']) : '';
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$itemsPerPage = isset($_GET['itemsPerPage']) ? max(1, intval($_GET['itemsPerPage'])) : 10;
$languages = isset($_GET['languages']) ? explode(',', $_GET['languages']) : ['English', 'Chinese'];


// solr start -Dsolr.disable.allowUrls=true

$_solr_url = "http://localhost:8983/solr/library_en/select?q=$query&shards=localhost:8983/solr/library_en,localhost:8983/solr/library_zh,localhost:8983/solr/library_ja,localhost:8983/solr/library_ko&defType=edismax&qf=title^3.0+author^2.0+category^2.0+summary^1.5+year^0.5&fl=id,title,category,author,score,year,summary&wt=json";

$start = ($page - 1) * $itemsPerPage;

$filter = "&rows=$itemsPerPage&start=$start";




$solr_url = $_solr_url . $filter;

$ch = curl_init($solr_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);

$results = json_decode($response, true);

$filteredJournals = [];
// Calculate pagination
$totalCount = 0;
$totalPages = 1;//ceil($totalCount / $itemsPerPage);

// Get paginated results
// $startIndex = ($page - 1) * $itemsPerPage;
// $paginatedJournals = array_slice($filteredJournals, $startIndex, $itemsPerPage);

if (isset($results['response'])) {
    $filteredJournals = array_values($results['response']['docs']);
    $totalCount = $results['response']['numFound'];
    $totalPages = ceil($totalCount / $itemsPerPage);
}
// Reset array keys



// Prepare response
$response = array(
    'journals' => $filteredJournals,
    'totalPages' => $totalPages,
    'currentPage' => $page,
    'totalResults' => $totalCount
);

echo json_encode($response);